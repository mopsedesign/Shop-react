import { Search, Bell, User, ArrowLeft, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  isSearchOpen: boolean;
  onSearchToggle: () => void;
}

export function Header({ isSearchOpen, onSearchToggle }: HeaderProps) {
  return (
    <header className="h-[56px] px-4 flex items-center justify-between bg-white border-b border-[#F0F0F0] relative">
      <AnimatePresence mode="wait">
        {!isSearchOpen ? (
          <motion.div
            key="default"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="flex items-center justify-between w-full"
          >
            {/* Logo */}
            <div className="text-[28px] font-bold text-[#E8638C]">МАРТ</div>

            {/* Icons */}
            <div className="flex items-center gap-3">
              <button
                onClick={onSearchToggle}
                className="text-[#888888] hover:text-[#1A1A1A] transition-colors"
              >
                <Search size={24} />
              </button>
              <button className="text-[#888888] hover:text-[#1A1A1A] transition-colors">
                <Bell size={24} />
              </button>
              <button className="w-[40px] h-[40px] rounded-[12px] bg-[#E8638C] flex items-center justify-center text-white hover:bg-[#d9537a] transition-colors">
                <User size={20} />
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="search"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="flex items-center gap-3 w-full"
          >
            <button
              onClick={onSearchToggle}
              className="text-[#888888] hover:text-[#1A1A1A] transition-colors"
            >
              <ArrowLeft size={24} />
            </button>

            <div className="flex-1 relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#888888]">
                <Search size={18} />
              </div>
              <input
                type="text"
                placeholder="Поиск"
                className="w-full h-[40px] bg-[#F5F5F5] rounded-[12px] pl-10 pr-4 text-[14px] text-[#1A1A1A] placeholder:text-[#888888] focus:outline-none focus:ring-2 focus:ring-[#E8638C]/20"
                autoFocus
              />
            </div>

            <button
              onClick={onSearchToggle}
              className="text-[#888888] hover:text-[#1A1A1A] transition-colors"
            >
              <X size={24} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

export default Header;
