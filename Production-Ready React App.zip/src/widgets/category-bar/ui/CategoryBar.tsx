import { Plus, Pencil } from 'lucide-react';
import { CategoryItem } from '../../../entities/category';
import type { Category } from '../../../entities/category';

interface CategoryBarProps {
  categories: Category[];
  onCategoryClick: (categoryId: string) => void;
  onEditClick?: () => void;
}

export function CategoryBar({ categories, onCategoryClick, onEditClick }: CategoryBarProps) {
  return (
    <div className="bg-white border-b border-[#F0F0F0]">
      {/* Header row (fixed, does NOT scroll) */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <h2 className="text-[18px] font-bold text-[#1A1A1A]">Категории</h2>
          <button className="text-[#888888] hover:text-[#1A1A1A] transition-colors">
            <Plus size={24} />
          </button>
        </div>
        <button
          onClick={onEditClick}
          className="flex items-center gap-1 text-[#888888] hover:text-[#1A1A1A] transition-colors"
        >
          <Pencil size={14} />
          <span className="text-[13px]">Изм.</span>
        </button>
      </div>

      {/* Icons scroll container */}
      <div className="overflow-x-scroll px-4 pb-3 [&::-webkit-scrollbar]:hidden">
        <div className="flex gap-3">
          {categories.map((category) => (
            <CategoryItem
              key={category.id}
              category={category}
              onClick={() => onCategoryClick(category.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default CategoryBar;
