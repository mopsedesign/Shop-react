import { ShoppingCart, Calculator, PlusSquare, MessageCircle, Menu } from 'lucide-react';
import { cn } from '../../../shared/lib/cn';

interface BottomNavProps {
  activeTab?: string;
}

export function BottomNav({ activeTab = 'shop' }: BottomNavProps) {
  const tabs = [
    { id: 'shop', label: 'Магазин', icon: ShoppingCart },
    { id: 'checkout', label: 'Касса', icon: Calculator },
    { id: 'create', label: 'Создать', icon: PlusSquare },
    { id: 'chat', label: 'Чат', icon: MessageCircle },
    { id: 'more', label: 'Ещё', icon: Menu },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-[80px] bg-white border-t border-[#F0F0F0] shadow-[0_-2px_12px_rgba(0,0,0,0.06)] z-30 max-w-[390px] mx-auto">
      <div className="flex items-center justify-around h-full px-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              className="flex flex-col items-center justify-center gap-1 flex-1 py-2"
            >
              <div
                className={cn(
                  'flex items-center justify-center transition-all',
                  isActive
                    ? 'w-[36px] h-[36px] bg-[#E8638C] rounded-[10px]'
                    : 'w-[24px] h-[24px]'
                )}
              >
                <Icon
                  size={isActive ? 20 : 24}
                  className={isActive ? 'text-white' : 'text-[#888888]'}
                />
              </div>
              <span
                className={cn(
                  'text-[11px]',
                  isActive ? 'text-[#E8638C] font-semibold' : 'text-[#888888]'
                )}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

export default BottomNav;
