import { motion, AnimatePresence } from 'motion/react';
import { Check } from 'lucide-react';
import { Button } from '../../../shared/ui/Button';

interface SortBottomSheetProps {
  isOpen: boolean;
  selectedSort: string;
  sortOptions: string[];
  onClose: () => void;
  onSelect: (option: string) => void;
}

export function SortBottomSheet({
  isOpen,
  selectedSort,
  sortOptions,
  onClose,
  onSelect,
}: SortBottomSheetProps) {
  const handleSelect = (option: string) => {
    onSelect(option);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            className="fixed inset-0 bg-black/40 z-40"
            onClick={onClose}
          />

          {/* Sheet */}
          <motion.div
            initial={{ y: '100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.32, 0.72, 0, 1] }}
            className="fixed bottom-0 left-0 right-0 bg-white rounded-t-[20px] z-50 max-w-[390px] mx-auto"
          >
            <div className="px-4 pt-5 pb-5">
              {/* Handle bar */}
              <div className="w-[40px] h-[4px] bg-[#E0E0E0] rounded-[2px] mx-auto mb-5" />

              {/* Title */}
              <h3 className="text-[16px] font-bold text-[#1A1A1A] mb-4">Сортировка</h3>

              {/* Sort options */}
              <div className="mb-4">
                {sortOptions.map((option) => (
                  <button
                    key={option}
                    onClick={() => handleSelect(option)}
                    className="flex items-center justify-between w-full h-[48px] border-b border-[#F5F5F5] hover:bg-[#F5F5F5] transition-colors"
                  >
                    <span
                      className={`text-[14px] ${
                        selectedSort === option ? 'text-[#E8638C]' : 'text-[#1A1A1A]'
                      }`}
                    >
                      {option}
                    </span>
                    {selectedSort === option && (
                      <Check size={20} className="text-[#E8638C]" />
                    )}
                  </button>
                ))}
              </div>

              {/* Done button */}
              <Button variant="primary" size="lg" fullWidth onClick={onClose}>
                Готово
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

export default SortBottomSheet;
