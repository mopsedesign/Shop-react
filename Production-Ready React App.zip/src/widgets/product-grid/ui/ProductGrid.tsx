import { ProductCardGrid, ProductCardList } from '../../../entities/product';
import type { Product } from '../../../entities/product';
import { SortBar } from './SortBar';

interface ProductGridProps {
  products: Product[];
  layoutMode: 'grid' | 'list';
  onLayoutToggle: () => void;
  onSortClick: () => void;
}

export function ProductGrid({
  products,
  layoutMode,
  onLayoutToggle,
  onSortClick,
}: ProductGridProps) {
  const CardComponent = layoutMode === 'grid' ? ProductCardGrid : ProductCardList;

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      <SortBar
        layoutMode={layoutMode}
        onLayoutToggle={onLayoutToggle}
        onSortClick={onSortClick}
      />

      <div className="flex-1 overflow-y-scroll [&::-webkit-scrollbar]:hidden px-3 pt-3 pb-20">
        <div
          className={
            layoutMode === 'grid'
              ? 'grid grid-cols-2 gap-3'
              : 'flex flex-col gap-3'
          }
        >
          {products.map((product) => (
            <CardComponent key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default ProductGrid;
