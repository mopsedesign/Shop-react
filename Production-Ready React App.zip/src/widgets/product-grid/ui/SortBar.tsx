import { ChevronDown, Grid3x3, List } from 'lucide-react';

interface SortBarProps {
  layoutMode: 'grid' | 'list';
  onLayoutToggle: () => void;
  onSortClick: () => void;
}

export function SortBar({ layoutMode, onLayoutToggle, onSortClick }: SortBarProps) {
  return (
    <div className="h-[44px] px-4 flex items-center justify-between border-b border-[#F0F0F0] bg-white">
      <button
        onClick={onSortClick}
        className="flex items-center gap-1 text-[14px] text-[#1A1A1A] hover:text-[#E8638C] transition-colors"
      >
        <span>Сортировка</span>
        <ChevronDown size={16} />
      </button>

      <button
        onClick={onLayoutToggle}
        className="w-[28px] h-[28px] bg-[#F5F5F5] rounded-[8px] flex items-center justify-center text-[#888888] hover:text-[#1A1A1A] transition-colors"
      >
        {layoutMode === 'grid' ? <Grid3x3 size={16} /> : <List size={16} />}
      </button>
    </div>
  );
}

export default SortBar;
