You are generating a production-ready React + TypeScript application 
following Feature-Sliced Design (FSD) methodology strictly.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TECH STACK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- React 18 + TypeScript
- Tailwind CSS (no other CSS frameworks)
- Framer Motion (animations only)
- React Router v6 (navigation)
- Mobile-first, max-width: 390px, centered

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DESIGN TOKENS (use as Tailwind config or CSS variables)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
--color-brand:        #E8638C
--color-brand-light:  #F9D0DC
--color-bg:           #FFFFFF
--color-surface:      #F5F5F5
--color-text-primary: #1A1A1A
--color-text-secondary: #888888
--color-success:      #4CAF50
--color-error:        #F44336
--color-border:       #E0E0E0
--radius-card:        16px
--radius-button:      12px
--radius-circle:      9999px

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FSD FOLDER STRUCTURE (strict)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
src/
├── app/
│   ├── App.tsx
│   ├── router.tsx
│   └── styles/
│       └── globals.css
│
├── pages/
│   └── shop/
│       ├── index.ts
│       └── ui/
│           └── ShopPage.tsx
│
├── widgets/
│   ├── header/
│   │   ├── index.ts
│   │   └── ui/
│   │       └── Header.tsx
│   ├── category-bar/
│   │   ├── index.ts
│   │   └── ui/
│   │       └── CategoryBar.tsx
│   ├── product-grid/
│   │   ├── index.ts
│   │   └── ui/
│   │       ├── ProductGrid.tsx
│   │       └── SortBar.tsx
│   ├── sort-bottom-sheet/
│   │   ├── index.ts
│   │   └── ui/
│   │       └── SortBottomSheet.tsx
│   └── bottom-nav/
│       ├── index.ts
│       └── ui/
│           └── BottomNav.tsx
│
├── entities/
│   ├── product/
│   │   ├── index.ts
│   │   ├── model/
│   │   │   └── types.ts
│   │   └── ui/
│   │       ├── ProductCardGrid.tsx
│   │       └── ProductCardList.tsx
│   └── category/
│       ├── index.ts
│       ├── model/
│       │   └── types.ts
│       └── ui/
│           └── CategoryItem.tsx
│
└── shared/
    ├── ui/
    │   ├── Button.tsx
    │   ├── EditButton.tsx
    │   └── StatusDot.tsx
    ├── config/
    │   └── tokens.ts
    └── lib/
        └── cn.ts (classnames helper)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TYPES (entities)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// entities/product/model/types.ts
interface Product {
  id: string
  title: string
  article: string
  category: string
  composition: string[]
  packaging: string
  price: number
  images: string[]
  inStock: boolean
}

// entities/category/model/types.ts
interface Category {
  id: string
  name: string
  image: string
  isActive: boolean
  isAvailable: boolean  // true=green dot, false=red dot
}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MOCK DATA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Categories (5 items):
[
  { id:"1", name:"Готовые",    isActive:true,  isAvailable:true  },
  { id:"2", name:"Сборные",    isActive:true,  isAvailable:true  },
  { id:"3", name:"Монобукеты", isActive:false, isAvailable:false },
  { id:"4", name:"Розы",       isActive:false, isAvailable:true  },
  { id:"5", name:"Тюльпаны",   isActive:false, isAvailable:true  },
]

Products (6 items):
[
  {
    id:"1",
    title:"Букет Праздничная композиция",
    article:"9587473",
    category:"Цветочные композиции",
    composition:["Тюльпан микс 60 см (4 шт)", "Розы ажурные 20 см (23 шт)"],
    packaging:"1шт",
    price:5600,
    inStock:true
  },
  // repeat with slight variations for 6 items total
]

Sort options:
["Сначала дешевле", "Сначала дороже", 
 "Сначала новые", "Сначала старые"]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
COMPONENT SPECS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

── HEADER ──────────────────────────────
Two states managed by isSearchOpen: boolean

State DEFAULT:
Left:  Logo "МАРТ" — font-size:28px, 
       color:#E8638C, font-weight:700
Right: Three icons in a row (gap:12px)
  1. Search icon (magnifier) — gray, 24px
  2. Notification Bell icon — gray, 24px
  3. User icon — white icon on brand pink 
     rounded square background 
     (40×40px, border-radius:12px, bg:#E8638C)

State SEARCH (triggered by search icon click):
Left:  Back arrow icon — gray, 24px
Center: Search Input field
  - placeholder: "Поиск"
  - bg: #F5F5F5
  - border-radius: 12px
  - height: 40px
  - search icon inside left
Right: Close (✕) icon — gray, 24px

Animation (Framer Motion):
- Default→Search: logo+icons fade out (opacity:0) 
  + slide up (y:-10px), search slides down (y:10px→0) 
  + fade in, duration:300ms ease-out
- Search→Default: reverse animation

── CATEGORY BAR ────────────────────────
Outer frame: width:390px, NO overflow
  
Header row (fixed, does NOT scroll):
- Left:  Text "Категории" (font-size:18px, 
         font-weight:700, color:#1A1A1A)
         + "+" icon button (24px, gray, margin-left:8px)
- Right: Edit button — ghost style, small
         pencil icon + text "Изм." 
         (font-size:13px, color:#888888)

Icons scroll container:
- width:390px, overflow-x:scroll, 
  hide scrollbar
- padding: 8px 16px

CategoryItem component:
- Container: width:72px, align-items:center
- Circle: 64×64px, border-radius:50%
  Active:   border: 2.5px solid #E8638C
  Inactive: border: 2.5px solid #E0E0E0
  bg: #F5F5F5
  Image: cover, fills circle
- StatusDot: 10×10px, border-radius:50%
  positioned bottom-right of circle
  isAvailable=true:  bg:#4CAF50
  isAvailable=false: bg:#F44336
- Label: font-size:12px, 
         color:#1A1A1A, margin-top:4px,
         text-align:center

── SORT BAR ────────────────────────────
Height: 44px
padding: 0 16px
display: flex, justify-content:space-between
align-items:center
border-bottom: 1px solid #F0F0F0

Left:  "Сортировка" text + chevron-down icon
       font-size:14px, color:#1A1A1A
       gap:4px between text and icon
       onClick → opens SortBottomSheet

Right: Layout Toggle Button (28×28px)
       State=Grid: grid-3x3 icon
       State=List: list icon
       bg: #F5F5F5, border-radius:8px
       onClick → toggles layout

── PRODUCT CARD (Grid variant) ──────────
Card: bg:#FFFFFF, border-radius:16px
      border: 1px solid #F0F0F0
      box-shadow: 0 2px 8px rgba(0,0,0,0.06)
      width: 100%, padding-bottom:12px

Image block:
- aspect-ratio: 4/3
- border-radius: 12px 12px 0 0
- overflow:hidden
- position:relative
Edit Button (top-right of image):
  - position:absolute, top:8px, right:8px
  - 28×28px, border-radius:8px
  - bg:#E8638C, color:white
  - pencil icon 14px

Info block (padding: 10px 12px 0):
- Title: font-size:14px, font-weight:700,
         color:#1A1A1A, margin-bottom:6px
         2 lines max
- "Артикул: 9587473" 
  font-size:12px, color:#888888
- "Категория:" label bold + value normal
  font-size:12px, color:#1A1A1A
- "Состав:" label bold, then list of items
  font-size:12px, color:#1A1A1A
- "Упаковка:" label bold + value
  font-size:12px, color:#1A1A1A

Price: font-size:18px, font-weight:700,
       color:#1A1A1A, text-align:right
       margin: 8px 0

Button "Продать":
  - width:100%, height:44px
  - bg:#E8638C, color:white
  - border-radius:12px
  - font-size:14px, font-weight:600

Link "Разобрать/удалить":
  - display:block, text-align:center
  - margin-top:8px
  - font-size:12px, color:#888888
  - text-decoration:underline

── PRODUCT GRID ────────────────────────
Outer frame: width:390px
  - display:flex, flex-direction:column
  - NO overflow on outer frame

Sort Bar: fixed at top (see above)

Cards Container:
  - overflow-y:scroll, hide scrollbar
  - flex:1
  - padding: 12px 12px 0

Cards Grid (Layout=Grid):
  - display:grid
  - grid-template-columns: 1fr 1fr
  - gap:12px

Cards Grid (Layout=List):
  - display:flex, flex-direction:column
  - gap:12px

── SORT BOTTOM SHEET ───────────────────
Overlay: fixed inset-0, bg:rgba(0,0,0,0.4)
         onClick overlay → close

Sheet: position:fixed, bottom:0
       width:390px, max-width:100%
       bg:#FFFFFF, border-radius:20px 20px 0 0
       padding: 20px 16px

Animation (Framer Motion):
  initial: y:100%, opacity:0
  animate: y:0, opacity:1
  exit:    y:100%, opacity:0
  duration: 350ms, ease:[0.32,0.72,0,1]

Handle bar: 40×4px, bg:#E0E0E0, 
            border-radius:2px, centered, margin-bottom:20px

Title: "Сортировка" font-size:16px font-weight:700

Sort options list:
Each option (height:48px):
  - display:flex, justify-content:space-between
  - align-items:center
  - border-bottom: 1px solid #F5F5F5
  Selected: text color:#E8638C + checkmark icon right
  Default:  text color:#1A1A1A

Button "Готово":
  - width:100%, height:52px
  - bg:#E8638C, color:white
  - border-radius:12px
  - margin-top:16px
  - onClick → apply sort + close sheet

── BOTTOM NAVIGATION ───────────────────
position:fixed, bottom:0, width:390px
height:80px (including safe area)
bg:#FFFFFF
border-top: 1px solid #F0F0F0
box-shadow: 0 -2px 12px rgba(0,0,0,0.06)

5 tabs (equal width):
1. Магазин   — cart icon
2. Касса     — calculator icon
3. Создать   — plus-square icon
4. Чат       — message-bubble icon
5. Ещё       — menu-lines icon

Active tab (Магазин):
  - Icon bg: #E8638C rounded square 
    (36×36px, border-radius:10px)
  - Icon color: white
  - Label color: #E8638C
  - font-size:11px, font-weight:600

Inactive tab:
  - Icon: gray #888888, 24px
  - Label: gray #888888
  - font-size:11px

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SHOPPAGE LAYOUT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ShopPage.tsx manages these states:
- isSearchOpen: boolean (false)
- layoutMode: 'grid' | 'list' ('grid')
- selectedSort: string ('Сначала новые')
- isSortOpen: boolean (false)
- activeCategory: string | null (null)

Layout structure:
┌─────────────────────────┐
│ Header (fixed top)      │ height:56px
├─────────────────────────┤
│ Category Bar (fixed)    │ height:140px
├─────────────────────────┤
│ Sort Bar (fixed)        │ height:44px
├─────────────────────────┤
│ Cards Container         │ flex:1
│ (scrollable)            │ overflow-y:scroll
├─────────────────────────┤
│ Bottom Nav (fixed)      │ height:80px
└─────────────────────────┘

Total: 390×844px (iPhone 14 size)
Main content area scrolls between Sort Bar and Bottom Nav

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SHARED/UI COMPONENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Button.tsx props:
  variant: 'primary' | 'ghost' | 'link'
  size: 'lg' | 'md' | 'sm' | 'xs'
  children, onClick, disabled, fullWidth

EditButton.tsx props:
  style: 'brand' | 'neutral'
  onClick

StatusDot.tsx props:
  isAvailable: boolean

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
IMPORTANT RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Every file must have a named export AND default export
2. Every index.ts must re-export its public API
3. Imports must follow FSD rules — 
   lower layers cannot import from upper layers:
   shared ← entities ← features ← widgets ← pages ← app
4. No inline styles — use Tailwind classes only
5. All text content in Russian as shown in design
6. Use placeholder images: 
   https://placehold.co/400x300/F5F5F5/888888
7. All icons from lucide-react library
8. Scrollbars hidden: 
   [&::-webkit-scrollbar]{display:none}
9. Generate ALL files separately, 
   show each file with its full path