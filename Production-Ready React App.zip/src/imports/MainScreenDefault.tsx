import svgPaths from "./svg-gmxl6zp2wm";
import imgProductImage from "figma:asset/30e4c6afb322f2b684dae571310b6693ba9f2846.png";
import imgEllipse37 from "figma:asset/6088019406cb0cbd8b759ad8dc94bce7a0a076f7.png";
import imgEllipse38 from "figma:asset/6088019406cb0cbd8b759ad8dc94bce7a0a076f7.png";
import imgEllipse39 from "figma:asset/3debbafa4694ee03f7b25bea47acbca50dacac76.png";
import imgEllipse40 from "figma:asset/3debbafa4694ee03f7b25bea47acbca50dacac76.png";
import imgEllipse41 from "figma:asset/3debbafa4694ee03f7b25bea47acbca50dacac76.png";

function Frame4() {
  return (
    <div className="h-[35.248px] relative shrink-0 w-[38.772px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38.7723 35.2476">
        <g id="Frame 427318340">
          <rect fill="#EA7C9F" height="35.2476" width="38.7723" />
          <path d={svgPaths.p19f74c80} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame52() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[136.23px] top-[-5px]">
      <Frame4 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Артикул: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            9587473
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Категория:</p>
      </div>
      <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center relative shrink-0 text-center w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Цветочные композиции</p>
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Состав:</p>
      </div>
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex flex-col font-['Roboto:Regular',sans-serif] font-normal gap-[2px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full">
      <div className="flex flex-col justify-center relative shrink-0 w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Тюльпан микс 60 см (4 шт)</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 w-[169px] whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none mb-0">{`Розы ажурные 20 см `}</p>
        <p className="leading-none">(23 шт)</p>
      </div>
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <Frame13 />
      <Frame19 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <Frame12 />
      <Frame10 />
      <Frame18 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] min-w-full relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Упаковка: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            1шт
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame29() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[16px] text-black w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-[19px]">{`Букет `}</span>
          <span className="leading-[19px] text-[#161616]">Праздничная композиция</span>
        </p>
      </div>
      <Frame20 />
    </div>
  );
}

function Frame27() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <div className="bg-[#ea7c9f] h-[32px] relative rounded-[10px] shrink-0 w-full" data-name="Buttons">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[58px] py-[5px] relative size-full">
            <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[12px] text-[12px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Продать
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="content-stretch flex h-[32px] items-center justify-center px-[58px] py-[5px] relative rounded-[10px] shrink-0 w-[172px]" data-name="Buttons">
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[0px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="decoration-solid leading-[12px] text-[12px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
            Разобрать/удалить
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame31() {
  return (
    <div className="content-stretch flex flex-col h-[288px] items-center justify-between relative shrink-0 w-full">
      <Frame29 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-black text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[19px]">{`5600 руб `}</p>
      </div>
      <Frame27 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="h-[35.248px] relative shrink-0 w-[38.772px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38.7723 35.2476">
        <g id="Frame 427318340">
          <rect fill="#EA7C9F" height="35.2476" width="38.7723" />
          <path d={svgPaths.p19f74c80} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame53() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[136.23px] top-[-5px]">
      <Frame5 />
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Артикул: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            9587473
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Категория:</p>
      </div>
      <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center relative shrink-0 text-center w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Цветочные композиции</p>
      </div>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Состав:</p>
      </div>
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex flex-col font-['Roboto:Regular',sans-serif] font-normal gap-[2px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full">
      <div className="flex flex-col justify-center relative shrink-0 w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Тюльпан микс 60 см (4 шт)</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Розы ажурные 20 см (3 шт)</p>
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <Frame15 />
      <Frame23 />
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <Frame14 />
      <Frame11 />
      <Frame22 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] min-w-full relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Упаковка: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            1шт
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame30() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[16px] text-black w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-[19px]">{`Букет `}</span>
          <span className="leading-[19px] text-[#161616]">Праздничная композиция</span>
        </p>
      </div>
      <Frame21 />
    </div>
  );
}

function Frame28() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <div className="bg-[#ea7c9f] h-[32px] relative rounded-[10px] shrink-0 w-full" data-name="Buttons">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[58px] py-[5px] relative size-full">
            <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[12px] text-[12px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Продать
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="content-stretch flex h-[32px] items-center justify-center px-[58px] py-[5px] relative rounded-[10px] shrink-0 w-[172px]" data-name="Buttons">
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[0px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="decoration-solid leading-[12px] text-[12px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
            Разобрать/удалить
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame32() {
  return (
    <div className="content-stretch flex flex-col h-[288px] items-center justify-between relative shrink-0 w-full">
      <Frame30 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-black text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[19px]">{`5600 руб `}</p>
      </div>
      <Frame28 />
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0">
      <div className="bg-white content-stretch flex flex-col gap-[16px] items-center p-[8px] relative rounded-[10px] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.25)] shrink-0 w-[185px]" data-name="Product card">
        <div className="content-stretch flex flex-col h-[109.248px] items-start overflow-clip pb-[79px] pl-[133px] relative rounded-[10px] shrink-0 w-[169px]" data-name="Product Image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[10px] size-full" src={imgProductImage} />
          <Frame52 />
        </div>
        <Frame31 />
      </div>
      <div className="bg-white content-stretch flex flex-col gap-[16px] items-center p-[8px] relative rounded-[10px] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.25)] shrink-0 w-[185px]" data-name="Product card">
        <div className="content-stretch flex flex-col h-[109.248px] items-start overflow-clip pb-[79px] pl-[133px] relative rounded-[10px] shrink-0 w-[169px]" data-name="Product Image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[10px] size-full" src={imgProductImage} />
          <Frame53 />
        </div>
        <Frame32 />
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="h-[35.248px] relative shrink-0 w-[38.772px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38.7723 35.2476">
        <g id="Frame 427318340">
          <rect fill="#EA7C9F" height="35.2476" width="38.7723" />
          <path d={svgPaths.p19f74c80} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame54() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[136.23px] top-[-5px]">
      <Frame6 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Артикул: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            9587473
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Категория:</p>
      </div>
      <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center relative shrink-0 text-center w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Цветочные композиции</p>
      </div>
    </div>
  );
}

function Frame36() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Состав:</p>
      </div>
    </div>
  );
}

function Frame37() {
  return (
    <div className="content-stretch flex flex-col font-['Roboto:Regular',sans-serif] font-normal gap-[2px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full">
      <div className="flex flex-col justify-center relative shrink-0 w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Тюльпан микс 60 см (4 шт)</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 w-[169px] whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none mb-0">{`Розы ажурные 20 см `}</p>
        <p className="leading-none">(23 шт)</p>
      </div>
    </div>
  );
}

function Frame35() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <Frame36 />
      <Frame37 />
    </div>
  );
}

function Frame26() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <Frame16 />
      <Frame17 />
      <Frame35 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] min-w-full relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Упаковка: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            1шт
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame34() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[16px] text-black w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-[19px]">{`Букет `}</span>
          <span className="leading-[19px] text-[#161616]">Праздничная композиция</span>
        </p>
      </div>
      <Frame26 />
    </div>
  );
}

function Frame38() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <div className="bg-[#ea7c9f] h-[32px] relative rounded-[10px] shrink-0 w-full" data-name="Buttons">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[58px] py-[5px] relative size-full">
            <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[12px] text-[12px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Продать
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="content-stretch flex h-[32px] items-center justify-center px-[58px] py-[5px] relative rounded-[10px] shrink-0 w-[172px]" data-name="Buttons">
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[0px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="decoration-solid leading-[12px] text-[12px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
            Разобрать/удалить
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame33() {
  return (
    <div className="content-stretch flex flex-col h-[288px] items-center justify-between relative shrink-0 w-full">
      <Frame34 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-black text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[19px]">{`5600 руб `}</p>
      </div>
      <Frame38 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="h-[35.248px] relative shrink-0 w-[38.772px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38.7723 35.2476">
        <g id="Frame 427318340">
          <rect fill="#EA7C9F" height="35.2476" width="38.7723" />
          <path d={svgPaths.p19f74c80} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame55() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[136.23px] top-[-5px]">
      <Frame7 />
    </div>
  );
}

function Frame42() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Артикул: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            9587473
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame43() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Категория:</p>
      </div>
      <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center relative shrink-0 text-center w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Цветочные композиции</p>
      </div>
    </div>
  );
}

function Frame45() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Состав:</p>
      </div>
    </div>
  );
}

function Frame46() {
  return (
    <div className="content-stretch flex flex-col font-['Roboto:Regular',sans-serif] font-normal gap-[2px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full">
      <div className="flex flex-col justify-center relative shrink-0 w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Тюльпан микс 60 см (4 шт)</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 w-[169px] whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none mb-0">{`Розы ажурные 20 см `}</p>
        <p className="leading-none">(23 шт)</p>
      </div>
    </div>
  );
}

function Frame44() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <Frame45 />
      <Frame46 />
    </div>
  );
}

function Frame41() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <Frame42 />
      <Frame43 />
      <Frame44 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] min-w-full relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Упаковка: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            1шт
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame40() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[16px] text-black w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-[19px]">{`Букет `}</span>
          <span className="leading-[19px] text-[#161616]">Праздничная композиция</span>
        </p>
      </div>
      <Frame41 />
    </div>
  );
}

function Frame47() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <div className="bg-[#ea7c9f] h-[32px] relative rounded-[10px] shrink-0 w-full" data-name="Buttons">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[58px] py-[5px] relative size-full">
            <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[12px] text-[12px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Продать
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="content-stretch flex h-[32px] items-center justify-center px-[58px] py-[5px] relative rounded-[10px] shrink-0 w-[172px]" data-name="Buttons">
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[0px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="decoration-solid leading-[12px] text-[12px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
            Разобрать/удалить
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame39() {
  return (
    <div className="content-stretch flex flex-col h-[288px] items-center justify-between relative shrink-0 w-full">
      <Frame40 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-black text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[19px]">{`5600 руб `}</p>
      </div>
      <Frame47 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <div className="bg-white content-stretch flex flex-col gap-[16px] items-center p-[8px] relative rounded-[10px] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.25)] shrink-0 w-[185px]" data-name="Product card">
        <div className="content-stretch flex flex-col h-[109.248px] items-start overflow-clip pb-[79px] pl-[133px] relative rounded-[10px] shrink-0 w-[169px]" data-name="Product Image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[10px] size-full" src={imgProductImage} />
          <Frame54 />
        </div>
        <Frame33 />
      </div>
      <div className="bg-white content-stretch flex flex-col gap-[16px] items-center p-[8px] relative rounded-[10px] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.25)] shrink-0 w-[185px]" data-name="Product card">
        <div className="content-stretch flex flex-col h-[109.248px] items-start overflow-clip pb-[79px] pl-[133px] relative rounded-[10px] shrink-0 w-[169px]" data-name="Product Image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[10px] size-full" src={imgProductImage} />
          <Frame55 />
        </div>
        <Frame39 />
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="h-[35.248px] relative shrink-0 w-[38.772px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38.7723 35.2476">
        <g id="Frame 427318340">
          <rect fill="#EA7C9F" height="35.2476" width="38.7723" />
          <path d={svgPaths.p19f74c80} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame56() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[136.23px] top-[-5px]">
      <Frame8 />
    </div>
  );
}

function Frame57() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Артикул: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            9587473
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame58() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Категория:</p>
      </div>
      <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center relative shrink-0 text-center w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Цветочные композиции</p>
      </div>
    </div>
  );
}

function Frame60() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Состав:</p>
      </div>
    </div>
  );
}

function Frame61() {
  return (
    <div className="content-stretch flex flex-col font-['Roboto:Regular',sans-serif] font-normal gap-[2px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full">
      <div className="flex flex-col justify-center relative shrink-0 w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Тюльпан микс 60 см (4 шт)</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 w-[169px] whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none mb-0">{`Розы ажурные 20 см `}</p>
        <p className="leading-none">(23 шт)</p>
      </div>
    </div>
  );
}

function Frame59() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <Frame60 />
      <Frame61 />
    </div>
  );
}

function Frame51() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <Frame57 />
      <Frame58 />
      <Frame59 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] min-w-full relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Упаковка: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            1шт
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame50() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[16px] text-black w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-[19px]">{`Букет `}</span>
          <span className="leading-[19px] text-[#161616]">Праздничная композиция</span>
        </p>
      </div>
      <Frame51 />
    </div>
  );
}

function Frame62() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <div className="bg-[#ea7c9f] h-[32px] relative rounded-[10px] shrink-0 w-full" data-name="Buttons">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[58px] py-[5px] relative size-full">
            <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[12px] text-[12px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Продать
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="content-stretch flex h-[32px] items-center justify-center px-[58px] py-[5px] relative rounded-[10px] shrink-0 w-[172px]" data-name="Buttons">
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[0px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="decoration-solid leading-[12px] text-[12px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
            Разобрать/удалить
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame49() {
  return (
    <div className="content-stretch flex flex-col h-[288px] items-center justify-between relative shrink-0 w-full">
      <Frame50 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-black text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[19px]">{`5600 руб `}</p>
      </div>
      <Frame62 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="h-[35.248px] relative shrink-0 w-[38.772px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38.7723 35.2476">
        <g id="Frame 427318340">
          <rect fill="#EA7C9F" height="35.2476" width="38.7723" />
          <path d={svgPaths.p19f74c80} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame63() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-[136.23px] top-[-5px]">
      <Frame9 />
    </div>
  );
}

function Frame67() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Артикул: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            9587473
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame68() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center relative shrink-0 w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Категория:</p>
      </div>
      <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center relative shrink-0 text-center w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Цветочные композиции</p>
      </div>
    </div>
  );
}

function Frame70() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[144px]">
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[144px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Состав:</p>
      </div>
    </div>
  );
}

function Frame71() {
  return (
    <div className="content-stretch flex flex-col font-['Roboto:Regular',sans-serif] font-normal gap-[2px] items-start leading-[0] relative shrink-0 text-[12px] text-black tracking-[0.38px] w-full">
      <div className="flex flex-col justify-center relative shrink-0 w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none">Тюльпан микс 60 см (4 шт)</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 w-[169px] whitespace-pre-wrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-none mb-0">{`Розы ажурные 20 см `}</p>
        <p className="leading-none">(23 шт)</p>
      </div>
    </div>
  );
}

function Frame69() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <Frame70 />
      <Frame71 />
    </div>
  );
}

function Frame66() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <Frame67 />
      <Frame68 />
      <Frame69 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] min-w-full relative shrink-0 text-[12px] text-black tracking-[0.38px] w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-none">{`Упаковка: `}</span>
          <span className="font-['Roboto:Regular',sans-serif] font-normal leading-none" style={{ fontVariationSettings: "'wdth' 100" }}>
            1шт
          </span>
        </p>
      </div>
    </div>
  );
}

function Frame65() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[16px] text-black w-[169px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p>
          <span className="leading-[19px]">{`Букет `}</span>
          <span className="leading-[19px] text-[#161616]">Праздничная композиция</span>
        </p>
      </div>
      <Frame66 />
    </div>
  );
}

function Frame72() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0 w-full">
      <div className="bg-[#ea7c9f] h-[32px] relative rounded-[10px] shrink-0 w-full" data-name="Buttons">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[58px] py-[5px] relative size-full">
            <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-white whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              <p className="font-['Roboto:Bold',sans-serif] font-bold leading-[12px] text-[12px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Продать
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="content-stretch flex h-[32px] items-center justify-center px-[58px] py-[5px] relative rounded-[10px] shrink-0 w-[172px]" data-name="Buttons">
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[0px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="decoration-solid leading-[12px] text-[12px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
            Разобрать/удалить
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame64() {
  return (
    <div className="content-stretch flex flex-col h-[288px] items-center justify-between relative shrink-0 w-full">
      <Frame65 />
      <div className="flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-black text-right w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[19px]">{`5600 руб `}</p>
      </div>
      <Frame72 />
    </div>
  );
}

function Frame48() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0">
      <div className="bg-white content-stretch flex flex-col gap-[16px] items-center p-[8px] relative rounded-[10px] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.25)] shrink-0 w-[185px]" data-name="Product card">
        <div className="content-stretch flex flex-col h-[109.248px] items-start overflow-clip pb-[79px] pl-[133px] relative rounded-[10px] shrink-0 w-[169px]" data-name="Product Image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[10px] size-full" src={imgProductImage} />
          <Frame56 />
        </div>
        <Frame49 />
      </div>
      <div className="bg-white content-stretch flex flex-col gap-[16px] items-center p-[8px] relative rounded-[10px] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.25)] shrink-0 w-[185px]" data-name="Product card">
        <div className="content-stretch flex flex-col h-[109.248px] items-start overflow-clip pb-[79px] pl-[133px] relative rounded-[10px] shrink-0 w-[169px]" data-name="Product Image">
          <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none rounded-[10px] size-full" src={imgProductImage} />
          <Frame63 />
        </div>
        <Frame64 />
      </div>
    </div>
  );
}

function Frame77() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] items-start left-0 right-0 top-[-3px]">
      <Frame24 />
      <Frame25 />
      <Frame48 />
    </div>
  );
}

function Group() {
  return (
    <div className="h-[19.796px] relative shrink-0 w-[115.31px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 115.311 19.7962">
        <g id="Group 54">
          <path d={svgPaths.p10754f00} fill="var(--fill-0, #EA7C9F)" id="Vector" />
          <path d={svgPaths.p323b8180} fill="var(--fill-0, #EA7C9F)" id="Vector_2" />
          <path d={svgPaths.p23f57940} fill="var(--fill-0, #EA7C9F)" id="Vector_3" />
          <path d={svgPaths.p1c62c700} fill="var(--fill-0, #EA7C9F)" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0">
      <div className="bg-[#f0f0f0] content-stretch flex items-center justify-center pb-[8px] pl-[11px] pr-[8px] pt-[9px] relative rounded-[5px] shrink-0 size-[37px]">
        <div className="relative shrink-0 size-[18px]" data-name="Vector">
          <div className="absolute inset-[-6.94%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.5 20.5">
              <path d={svgPaths.p15374e00} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
            </svg>
          </div>
        </div>
      </div>
      <div className="bg-[#f0f0f0] content-stretch flex gap-[10px] items-center justify-center p-[8px] relative rounded-[5px] shrink-0 size-[37px]" data-name="Notification Button">
        <div className="overflow-clip relative shrink-0 size-[24px]" data-name="Communication / Bell">
          <div className="absolute inset-[12.5%_16.67%]" data-name="Vector">
            <div className="absolute inset-[-6.94%_-7.82%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.501 20.5">
                <path d={svgPaths.p30668200} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
              </svg>
            </div>
          </div>
        </div>
        <div className="absolute left-[20.91px] size-[8px] top-[5.5px]">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
            <circle cx="4" cy="4" fill="var(--fill-0, #EA7C9F)" id="Ellipse 50" r="4" />
          </svg>
        </div>
      </div>
      <div className="bg-[#ea7c9f] overflow-clip relative rounded-[5px] shrink-0 size-[37px]" data-name="User / User_Circle">
        <div className="absolute inset-[12.5%]" data-name="Vector">
          <div className="absolute inset-[-4.5%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30.25 30.25">
              <path d={svgPaths.p3b471180} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function LogoAndSearchNotifications() {
  return (
    <div className="absolute content-stretch flex h-[37px] items-center justify-between left-[16px] right-[16px] top-[47.5px]" data-name="Logo and search,notifications...">
      <Group />
      <Frame1 />
    </div>
  );
}

function Frame73() {
  return (
    <div className="content-stretch flex gap-[5px] items-center relative shrink-0">
      <div className="flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[16px] text-black text-center whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[19px]">Сортировка</p>
      </div>
      <div className="flex h-[6.944px] items-center justify-center relative shrink-0 w-[11.217px]" style={{ "--transform-inner-width": "1185", "--transform-inner-height": "21" } as React.CSSProperties}>
        <div className="-rotate-90 flex-none">
          <div className="h-[11.217px] relative w-[6.944px]" data-name="icon">
            <div className="absolute inset-[3.4%_5.57%_3.4%_6%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.14023 10.4538">
                <path d={svgPaths.p2cf69c00} fill="var(--fill-0, #161616)" id="icon" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SortAndGridButton() {
  return (
    <div className="absolute content-stretch flex h-[52px] items-center justify-between left-[16px] right-[16px] top-[calc(25%+12.46px)]" data-name="Sort and grid button">
      <Frame73 />
      <div className="bg-[#f0f0f0] content-stretch flex h-[44px] items-center justify-center p-[4px] relative rounded-[10px] shrink-0 w-[45.342px]" data-name="Layout Toggle">
        <div className="relative shrink-0 size-[20px]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
            <path d={svgPaths.pfb06440} fill="var(--fill-0, #666666)" id="Vector" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame76() {
  return (
    <div className="relative shrink-0 size-[21.207px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.207 21.207">
        <g id="Frame 427318371">
          <rect fill="var(--fill-0, #F0F0F0)" height="21.207" rx="10.6035" width="21.207" />
          <path d={svgPaths.p3b7bdb80} fill="var(--fill-0, #8A8A8A)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame75() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[18px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[21px]">Категории</p>
      </div>
      <Frame76 />
    </div>
  );
}

function Frame74() {
  return (
    <div className="absolute content-stretch flex h-[21.207px] items-start justify-between left-0 top-0 w-[385px]">
      <Frame75 />
      <div className="bg-[#f0f0f0] content-stretch flex gap-[4px] h-[21px] items-center justify-center p-[2.495px] relative rounded-[10.724px] shrink-0 w-[57px]">
        <div className="overflow-clip relative shrink-0 size-[15.844px]" data-name="Edit / Edit_Pencil_01">
          <div className="absolute inset-[18.39%_18.39%_16.67%_16.67%]" data-name="Vector">
            <div className="absolute inset-[-6.42%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.6094 11.6095">
                <path d={svgPaths.pd33e200} id="Vector" stroke="var(--stroke-0, #8A8A8A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.32031" />
              </svg>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#666] text-[12px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="leading-[12px]">Изм.</p>
        </div>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-center justify-center max-w-[72px] relative shrink-0">
      <div className="relative shrink-0 size-[80px]">
        <img alt="" className="absolute block max-w-none size-full" height="80" src={imgEllipse41} width="80" />
      </div>
      <p className="font-['Roboto:Regular',sans-serif] font-normal h-[24px] leading-[12px] max-w-[72px] relative shrink-0 text-[12px] text-black w-[72px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Подарочные коробкт
      </p>
    </div>
  );
}

function Frame2() {
  return (
    <div className="absolute content-stretch flex gap-[18px] h-[116px] items-start left-0 pt-[8px] top-0">
      <button className="content-stretch cursor-pointer flex flex-col gap-[4px] items-center justify-center max-w-[80px] relative shrink-0">
        <div className="relative shrink-0 size-[80px]">
          <img alt="" className="absolute block max-w-none size-full" height="80" src={imgEllipse37} width="80" />
        </div>
        <p className="font-['Roboto:Regular',sans-serif] font-normal h-[24px] leading-[12px] max-w-[80px] min-w-full relative shrink-0 text-[12px] text-black text-center w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
          Готовые
        </p>
        <div className="absolute left-[65px] size-[8.937px] top-[71px]">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.93652 8.93652">
            <circle cx="4.46826" cy="4.46826" fill="var(--fill-0, #61F34A)" id="Ellipse 38" r="4.46826" />
          </svg>
        </div>
      </button>
      <button className="content-stretch cursor-pointer flex flex-col gap-[4px] items-center justify-center max-w-[80px] relative shrink-0">
        <div className="relative shrink-0 size-[80px]">
          <img alt="" className="absolute block max-w-none size-full" height="80" src={imgEllipse38} width="80" />
        </div>
        <p className="font-['Roboto:Regular',sans-serif] font-normal h-[24px] leading-[12px] max-w-[80px] min-w-full relative shrink-0 text-[12px] text-black text-center w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
          Сборные
        </p>
        <div className="absolute left-[65px] size-[8.937px] top-[71px]">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.93652 8.93652">
            <circle cx="4.46826" cy="4.46826" fill="var(--fill-0, #61F34A)" id="Ellipse 38" r="4.46826" />
          </svg>
        </div>
      </button>
      <button className="content-stretch cursor-pointer flex flex-col gap-[4px] items-center justify-center max-w-[80px] relative shrink-0">
        <div className="relative shrink-0 size-[80px]">
          <img alt="" className="absolute block max-w-none size-full" height="80" src={imgEllipse39} width="80" />
        </div>
        <p className="font-['Roboto:Regular',sans-serif] font-normal h-[24px] leading-[12px] max-w-[80px] min-w-full relative shrink-0 text-[12px] text-black text-center w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
          Монобукеты
        </p>
        <div className="absolute left-[65px] size-[8.937px] top-[71px]">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.93652 8.93652">
            <circle cx="4.46826" cy="4.46826" fill="var(--fill-0, #FF3939)" id="Ellipse 38" r="4.46826" />
          </svg>
        </div>
      </button>
      <button className="content-stretch cursor-pointer flex flex-col gap-[4px] items-center justify-center max-w-[80px] relative shrink-0">
        <div className="relative shrink-0 size-[80px]">
          <img alt="" className="absolute block max-w-none size-full" height="80" src={imgEllipse40} width="80" />
        </div>
        <p className="font-['Roboto:Regular',sans-serif] font-normal h-[24px] leading-[12px] max-w-[80px] min-w-full relative shrink-0 text-[12px] text-black text-center w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
          Розы
        </p>
        <div className="absolute left-[65px] size-[8.937px] top-[71px]">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.93652 8.93652">
            <circle cx="4.46826" cy="4.46826" fill="var(--fill-0, #61F34A)" id="Ellipse 38" r="4.46826" />
          </svg>
        </div>
      </button>
      <button className="content-stretch cursor-pointer flex flex-col gap-[4px] items-center justify-center max-w-[80px] relative shrink-0">
        <div className="relative shrink-0 size-[80px]">
          <img alt="" className="absolute block max-w-none size-full" height="80" src={imgEllipse41} width="80" />
        </div>
        <p className="font-['Roboto:Regular',sans-serif] font-normal h-[24px] leading-[12px] max-w-[80px] min-w-full relative shrink-0 text-[12px] text-black text-center w-[min-content]" style={{ fontVariationSettings: "'wdth' 100" }}>
          Цветочные композиции
        </p>
        <div className="absolute left-[65px] size-[8.937px] top-[71px]">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.93652 8.93652">
            <circle cx="4.46826" cy="4.46826" fill="var(--fill-0, #61F34A)" id="Ellipse 38" r="4.46826" />
          </svg>
        </div>
      </button>
      <Frame3 />
    </div>
  );
}

function Frame78() {
  return (
    <div className="absolute h-[116px] left-0 overflow-x-auto overflow-y-clip top-[21px] w-[385px]">
      <Frame2 />
    </div>
  );
}

function Category() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col items-start left-[16px] right-[16px] top-[calc(8.33%+28.08px)]" data-name="Category">
      <div className="h-[137.207px] relative shrink-0 w-full" data-name="Category flower bar">
        <Frame74 />
        <Frame78 />
      </div>
    </div>
  );
}

function Clock() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="clock">
      <p className="relative shrink-0" style={{ fontVariationSettings: "'wdth' 100" }}>
        09
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'wdth' 100" }}>
        :
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'wdth' 100" }}>
        30
      </p>
    </div>
  );
}

function Icons() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-end relative shrink-0" data-name="Icons">
      <div className="relative shrink-0 size-[14px]" data-name="Android/Bluetooth">
        <div className="absolute h-[14px] left-[2.5px] top-0 w-[8.714px]" data-name="bluetooth">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.714 14">
            <path d={svgPaths.p20c9e780} fill="var(--fill-0, black)" id="bluetooth" />
          </svg>
        </div>
      </div>
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Android/WiFi">
        <div className="absolute flex inset-[76.36%_41.07%_5.41%_40.47%] items-center justify-center">
          <div className="flex-none h-[2.552px] rotate-180 w-[2.769px]">
            <div className="relative size-full" data-name="Bar 1">
              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2.76947 2.55202">
                <path d={svgPaths.p3e5d94f0} fill="var(--fill-0, black)" id="Bar 1" />
              </svg>
            </div>
          </div>
        </div>
        <div className="absolute inset-[53.07%_33.69%_37.79%_33.09%]" data-name="Bar 2">
          <div className="absolute inset-[-78.12%_-20.07%_-78.13%_-20.07%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6.98243 3.28032">
              <path d={svgPaths.p22f6a920} id="Bar 2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
        <div className="absolute inset-[26.54%_16.97%_57.46%_16.12%]" data-name="Bar 3">
          <div className="absolute inset-[-44.68%_-9.96%_-44.66%_-9.96%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.0361 4.2393">
              <path d={svgPaths.p7f84b00} id="Bar 3" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
        <div className="absolute inset-[0_0_77.14%_0]" data-name="Bar 4">
          <div className="absolute inset-[-31.29%_-6.67%_-31.25%_-6.67%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 5.20114">
              <path d={svgPaths.p6277d00} id="Bar 4" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
      </div>
      <div className="h-[16px] overflow-clip relative shrink-0 w-[18px]" data-name="Android/Cellular Signal">
        <p className="absolute font-['Roboto:Regular',sans-serif] font-normal inset-[0_55.56%_56.25%_0] leading-[normal] text-[6px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          5G
        </p>
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 16">
          <g id="bars">
            <path d={svgPaths.p2f573f40} fill="var(--fill-0, black)" id="Bar 1" />
            <path d={svgPaths.p34c12480} fill="var(--fill-0, black)" id="Bar 2" />
            <path d={svgPaths.pd464480} fill="var(--fill-0, black)" id="Bar 3" />
            <path d={svgPaths.p8b3fe00} fill="var(--fill-0, black)" id="Bar 4" />
          </g>
        </svg>
      </div>
      <div className="h-[11px] relative shrink-0 w-[18.5px]" data-name="Android/Battery">
        <div className="absolute inset-[-4.55%_-2.7%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.5 12">
            <path d={svgPaths.p189ab772} id="outline" stroke="var(--stroke-0, black)" />
          </svg>
        </div>
        <div className="absolute bg-black inset-[13.64%_16.22%_13.64%_8.11%] rounded-[2px]" data-name="indicator" />
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex items-center justify-between px-[8px] relative shrink-0 w-[380px]">
      <div className="absolute bg-[#ea7c9f] h-[63px] left-[8px] rounded-[15px] top-0 w-[67px]" />
      <div className="content-stretch flex flex-col gap-[1.683px] h-[63px] items-center p-[8px] relative rounded-[15px] shrink-0 w-[67px]" data-name="Shop icon">
        <div className="overflow-clip relative shrink-0 size-[33.668px]" data-name="Interface / Shopping_Cart_02">
          <div className="absolute inset-[12.5%_13.63%_12.5%_12.5%]" data-name="Vector">
            <div className="absolute inset-[-5.56%_-5.64%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27.6779 28.057">
                <g id="Vector">
                  <path d={svgPaths.p1a7e5b80} fill="var(--fill-0, white)" />
                  <path d={svgPaths.p24f13580} fill="var(--fill-0, white)" />
                  <path d={svgPaths.p82ad200} stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.8057" />
                </g>
              </svg>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[12px] text-white w-[51.381px]" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="leading-[12px]">Магазин</p>
        </div>
      </div>
      <button className="content-stretch cursor-pointer flex flex-col h-[63px] items-center justify-between p-[8px] relative rounded-[15px] shrink-0 w-[67px]" data-name="Calculator icon">
        <div className="h-[26.84px] relative shrink-0 w-[22.867px]" data-name="Subtract">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.8672 26.8398">
            <path d={svgPaths.p103d6c00} fill="var(--fill-0, #666666)" id="Subtract" />
          </svg>
        </div>
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[12px] text-left w-[35.652px]" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="leading-[12px]">Касса</p>
        </div>
      </button>
      <button className="content-stretch cursor-pointer flex flex-col h-[63px] items-center justify-between p-[8px] relative rounded-[15px] shrink-0 w-[67px]">
        <div className="overflow-clip relative shrink-0 size-[33.668px]" data-name="Edit / Add_Plus_Square">
          <div className="absolute inset-[16.67%]" data-name="Vector">
            <div className="absolute inset-[-6.25%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25.2516 25.2513">
                <path d={svgPaths.p10a54c00} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.8057" />
              </svg>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[12px] text-left w-[49.284px]" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="leading-[12px]">Создать</p>
        </div>
      </button>
      <button className="content-stretch cursor-pointer flex flex-col h-[63px] items-center justify-between p-[8px] relative rounded-[15px] shrink-0 w-[67px]" data-name="Chat icon">
        <div className="overflow-clip relative shrink-0 size-[33.668px]" data-name="Communication / Chat_Dots">
          <div className="absolute inset-[16.67%_12.5%_12.84%_12.5%]" data-name="Vector">
            <div className="absolute inset-[-5.91%_-5.56%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28.057 26.5412">
                <path d={svgPaths.p116f2400} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.8057" />
              </svg>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[12px] text-center w-[41.944px]" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="leading-[12px]">Чат</p>
        </div>
      </button>
      <button className="content-stretch cursor-pointer flex flex-col h-[63px] items-center justify-between p-[8px] relative rounded-[15px] shrink-0 w-[67px]" data-name="More icon">
        <div className="overflow-clip relative shrink-0 size-[33.668px]" data-name="Menu / Hamburger_LG">
          <div className="absolute inset-[29.17%_12.5%]" data-name="Vector">
            <div className="absolute inset-[-10%_-5.56%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28.057 16.8342">
                <path d={svgPaths.p242e0040} id="Vector" stroke="var(--stroke-0, #666666)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.8057" />
              </svg>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-['Roboto:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#666] text-[12px] text-center w-[41.944px]" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="leading-[12px]">Ещё</p>
        </div>
      </button>
    </div>
  );
}

export default function MainScreenDefault() {
  return (
    <div className="bg-white relative size-full" data-name="Main screen/Default">
      <div className="absolute h-[934.495px] left-[16px] right-[16px] top-[calc(33.33%+3.83px)]" data-name="Product grid">
        <Frame77 />
      </div>
      <div className="absolute bg-white h-[300px] left-[0.74px] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.25)] top-0 w-[411.256px]" data-name="Up background" />
      <LogoAndSearchNotifications />
      <SortAndGridButton />
      <Category />
      <div className="absolute bg-white content-stretch flex items-center justify-between left-0 px-[16px] py-[4px] top-0 w-[412px]" data-name="Status Bar/Android">
        <div className="content-stretch flex font-['Roboto:Regular',sans-serif] font-normal gap-[2px] items-start leading-[normal] relative shrink-0 text-[12px] text-black whitespace-nowrap" data-name="Android/Time">
          <Clock />
          <p className="relative shrink-0" style={{ fontVariationSettings: "'wdth' 100" }}>
            PM
          </p>
        </div>
        <Icons />
      </div>
      <div className="absolute bg-white content-stretch flex flex-col h-[75px] items-start left-[16px] py-[6px] rounded-[15px] shadow-[0px_2px_5px_0px_rgba(0,0,0,0.25)] top-[calc(83.33%+55.83px)] w-[380px]" data-name="Toolbar">
        <Frame />
      </div>
    </div>
  );
}