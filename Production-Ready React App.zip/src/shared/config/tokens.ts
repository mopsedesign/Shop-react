export const tokens = {
  colors: {
    brand: '#E8638C',
    brandLight: '#F9D0DC',
    bg: '#FFFFFF',
    surface: '#F5F5F5',
    textPrimary: '#1A1A1A',
    textSecondary: '#888888',
    success: '#4CAF50',
    error: '#F44336',
    border: '#E0E0E0',
  },
  radius: {
    card: '16px',
    button: '12px',
    circle: '9999px',
  },
} as const;

export default tokens;
