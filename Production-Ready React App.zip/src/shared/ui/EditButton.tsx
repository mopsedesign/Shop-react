import { Pencil } from 'lucide-react';
import { cn } from '../lib/cn';

interface EditButtonProps {
  style?: 'brand' | 'neutral';
  onClick?: () => void;
  className?: string;
}

export function EditButton({ style = 'brand', onClick, className }: EditButtonProps) {
  const brandStyles = 'bg-[#E8638C] text-white';
  const neutralStyles = 'bg-[#F5F5F5] text-[#888888]';

  return (
    <button
      onClick={onClick}
      className={cn(
        'w-[28px] h-[28px] rounded-[8px] flex items-center justify-center transition-opacity hover:opacity-80',
        style === 'brand' ? brandStyles : neutralStyles,
        className
      )}
    >
      <Pencil size={14} />
    </button>
  );
}

export default EditButton;
