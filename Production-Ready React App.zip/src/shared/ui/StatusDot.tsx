import { cn } from '../lib/cn';

interface StatusDotProps {
  isAvailable: boolean;
  className?: string;
}

export function StatusDot({ isAvailable, className }: StatusDotProps) {
  return (
    <div
      className={cn(
        'w-[10px] h-[10px] rounded-full',
        isAvailable ? 'bg-[#4CAF50]' : 'bg-[#F44336]',
        className
      )}
    />
  );
}

export default StatusDot;
