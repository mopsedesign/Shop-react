import { ButtonHTMLAttributes, ReactNode } from 'react';
import { cn } from '../lib/cn';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'ghost' | 'link';
  size?: 'lg' | 'md' | 'sm' | 'xs';
  children: ReactNode;
  fullWidth?: boolean;
}

export function Button({
  variant = 'primary',
  size = 'md',
  children,
  fullWidth = false,
  className,
  ...props
}: ButtonProps) {
  const baseStyles = 'transition-colors duration-200 font-semibold flex items-center justify-center';

  const variantStyles = {
    primary: 'bg-[#E8638C] text-white hover:bg-[#d9537a] active:bg-[#c94669]',
    ghost: 'bg-transparent text-[#888888] hover:bg-[#F5F5F5]',
    link: 'bg-transparent text-[#888888] underline hover:text-[#1A1A1A]',
  };

  const sizeStyles = {
    lg: 'h-[52px] text-[14px] rounded-[12px] px-6',
    md: 'h-[44px] text-[14px] rounded-[12px] px-5',
    sm: 'h-[36px] text-[13px] rounded-[10px] px-4',
    xs: 'h-[28px] text-[12px] rounded-[8px] px-3',
  };

  return (
    <button
      className={cn(
        baseStyles,
        variantStyles[variant],
        sizeStyles[size],
        fullWidth && 'w-full',
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}

export default Button;
