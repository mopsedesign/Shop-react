export interface Product {
  id: string;
  title: string;
  article: string;
  category: string;
  composition: string[];
  packaging: string;
  price: number;
  images: string[];
  inStock: boolean;
}

export default Product;
