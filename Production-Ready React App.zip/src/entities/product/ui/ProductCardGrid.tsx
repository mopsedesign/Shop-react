import { EditButton } from '../../../shared/ui/EditButton';
import { Button } from '../../../shared/ui/Button';
import type { Product } from '../model/types';

interface ProductCardGridProps {
  product: Product;
}

export function ProductCardGrid({ product }: ProductCardGridProps) {
  return (
    <div className="bg-white rounded-[16px] border border-[#F0F0F0] shadow-[0_2px_8px_rgba(0,0,0,0.06)] overflow-hidden">
      {/* Image block */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={product.images[0]}
          alt={product.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2">
          <EditButton style="brand" />
        </div>
      </div>

      {/* Info block */}
      <div className="px-3 pt-2.5 pb-3">
        <h3 className="text-[14px] font-bold text-[#1A1A1A] mb-1.5 line-clamp-2 leading-tight">
          {product.title}
        </h3>

        <p className="text-[12px] text-[#888888] mb-0.5">
          <span className="font-bold">Артикул:</span> {product.article}
        </p>

        <p className="text-[12px] text-[#1A1A1A] mb-0.5">
          <span className="font-bold">Категория:</span> {product.category}
        </p>

        <div className="text-[12px] text-[#1A1A1A] mb-0.5">
          <span className="font-bold">Состав:</span>
          <ul className="list-none ml-0">
            {product.composition.map((item, index) => (
              <li key={index}>• {item}</li>
            ))}
          </ul>
        </div>

        <p className="text-[12px] text-[#1A1A1A]">
          <span className="font-bold">Упаковка:</span> {product.packaging}
        </p>

        <div className="text-[18px] font-bold text-[#1A1A1A] text-right my-2">
          {product.price} руб
        </div>

        <Button variant="primary" size="md" fullWidth>
          Продать
        </Button>

        <button className="block w-full text-center mt-2 text-[12px] text-[#888888] underline hover:text-[#1A1A1A] transition-colors">
          Разобрать/удалить
        </button>
      </div>
    </div>
  );
}

export default ProductCardGrid;
