import { StatusDot } from '../../../shared/ui/StatusDot';
import { cn } from '../../../shared/lib/cn';
import type { Category } from '../model/types';

interface CategoryItemProps {
  category: Category;
  onClick?: () => void;
}

export function CategoryItem({ category, onClick }: CategoryItemProps) {
  return (
    <div
      className="flex flex-col items-center w-[72px] shrink-0 cursor-pointer"
      onClick={onClick}
    >
      <div className="relative">
        <div
          className={cn(
            'w-[64px] h-[64px] rounded-full bg-[#F5F5F5] overflow-hidden',
            'border-[2.5px]',
            category.isActive ? 'border-[#E8638C]' : 'border-[#E0E0E0]'
          )}
        >
          <img
            src={category.image}
            alt={category.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute bottom-0 right-0">
          <StatusDot isAvailable={category.isAvailable} />
        </div>
      </div>
      <p className="text-[12px] text-[#1A1A1A] mt-1 text-center leading-tight">
        {category.name}
      </p>
    </div>
  );
}

export default CategoryItem;
