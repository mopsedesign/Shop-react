export interface Category {
  id: string;
  name: string;
  image: string;
  isActive: boolean;
  isAvailable: boolean;
}

export default Category;
