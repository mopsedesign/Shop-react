import { createBrowserRouter, Navigate } from 'react-router';
import { ShopPage } from '../pages/shop';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Navigate to="/shop" replace />,
  },
  {
    path: '/shop',
    element: <ShopPage />,
  },
]);

export default router;
