import { useState } from 'react';
import { Header } from '../../../widgets/header';
import { CategoryBar } from '../../../widgets/category-bar';
import { ProductGrid } from '../../../widgets/product-grid';
import { SortBottomSheet } from '../../../widgets/sort-bottom-sheet';
import { BottomNav } from '../../../widgets/bottom-nav';
import type { Category } from '../../../entities/category';
import type { Product } from '../../../entities/product';

// Mock data for categories
const mockCategories: Category[] = [
  {
    id: '1',
    name: 'Готовые',
    image: 'https://placehold.co/64x64/F5F5F5/888888?text=%D0%93',
    isActive: true,
    isAvailable: true,
  },
  {
    id: '2',
    name: 'Сборные',
    image: 'https://placehold.co/64x64/F5F5F5/888888?text=%D0%A1',
    isActive: true,
    isAvailable: true,
  },
  {
    id: '3',
    name: 'Монобукеты',
    image: 'https://placehold.co/64x64/F5F5F5/888888?text=%D0%9C',
    isActive: false,
    isAvailable: false,
  },
  {
    id: '4',
    name: 'Розы',
    image: 'https://placehold.co/64x64/F5F5F5/888888?text=%D0%A0',
    isActive: false,
    isAvailable: true,
  },
  {
    id: '5',
    name: 'Тюльпаны',
    image: 'https://placehold.co/64x64/F5F5F5/888888?text=%D0%A2',
    isActive: false,
    isAvailable: true,
  },
];

// Mock data for products
const mockProducts: Product[] = [
  {
    id: '1',
    title: 'Букет Праздничная композиция',
    article: '9587473',
    category: 'Цветочные композиции',
    composition: ['Тюльпан микс 60 см (4 шт)', 'Розы ажурные 20 см (23 шт)'],
    packaging: '1шт',
    price: 5600,
    images: ['https://placehold.co/400x300/F5F5F5/888888?text=Product+1'],
    inStock: true,
  },
  {
    id: '2',
    title: 'Букет Композиция Корпоративная',
    article: '9587474',
    category: 'Цветочные композиции',
    composition: ['Розы микс 50 см (4 шт)', 'Хризантемы 20 см (15 шт)'],
    packaging: '1шт',
    price: 5600,
    images: ['https://placehold.co/400x300/F5F5F5/888888?text=Product+2'],
    inStock: true,
  },
  {
    id: '3',
    title: 'Букет Романтическая композиция',
    article: '9587475',
    category: 'Цветочные композиции',
    composition: ['Розы красные 60 см (15 шт)', 'Альстромерия розовая (10 шт)'],
    packaging: '1шт',
    price: 5600,
    images: ['https://placehold.co/400x300/F5F5F5/888888?text=Product+3'],
    inStock: true,
  },
  {
    id: '4',
    title: 'Букет Весенняя композиция',
    article: '9587476',
    category: 'Цветочные композиции',
    composition: ['Тюльпаны желтые 50 см (20 шт)', 'Нарциссы (12 шт)'],
    packaging: '1шт',
    price: 5600,
    images: ['https://placehold.co/400x300/F5F5F5/888888?text=Product+4'],
    inStock: true,
  },
  {
    id: '5',
    title: 'Букет Летняя композиция',
    article: '9587477',
    category: 'Цветочные композиции',
    composition: ['Подсолнухи 70 см (7 шт)', 'Ромашки полевые (15 шт)'],
    packaging: '1шт',
    price: 5600,
    images: ['https://placehold.co/400x300/F5F5F5/888888?text=Product+5'],
    inStock: true,
  },
  {
    id: '6',
    title: 'Букет Осенняя композиция',
    article: '9587478',
    category: 'Цветочные композиции',
    composition: ['Хризантемы желтые 50 см (10 шт)', 'Георгины (8 шт)'],
    packaging: '1шт',
    price: 5600,
    images: ['https://placehold.co/400x300/F5F5F5/888888?text=Product+6'],
    inStock: true,
  },
];

const sortOptions = ['Сначала дешевле', 'Сначала дороже', 'Сначала новые', 'Сначала старые'];

export function ShopPage() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [layoutMode, setLayoutMode] = useState<'grid' | 'list'>('grid');
  const [selectedSort, setSelectedSort] = useState('Сначала новые');
  const [isSortOpen, setIsSortOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const handleSearchToggle = () => {
    setIsSearchOpen(!isSearchOpen);
  };

  const handleLayoutToggle = () => {
    setLayoutMode(layoutMode === 'grid' ? 'list' : 'grid');
  };

  const handleSortClick = () => {
    setIsSortOpen(true);
  };

  const handleSortClose = () => {
    setIsSortOpen(false);
  };

  const handleSortSelect = (option: string) => {
    setSelectedSort(option);
  };

  const handleCategoryClick = (categoryId: string) => {
    setActiveCategory(categoryId === activeCategory ? null : categoryId);
  };

  return (
    <div className="h-screen flex flex-col max-w-[390px] mx-auto bg-[#F5F5F5] overflow-hidden">
      <Header isSearchOpen={isSearchOpen} onSearchToggle={handleSearchToggle} />
      <CategoryBar
        categories={mockCategories}
        onCategoryClick={handleCategoryClick}
      />
      <ProductGrid
        products={mockProducts}
        layoutMode={layoutMode}
        onLayoutToggle={handleLayoutToggle}
        onSortClick={handleSortClick}
      />
      <BottomNav activeTab="shop" />
      <SortBottomSheet
        isOpen={isSortOpen}
        selectedSort={selectedSort}
        sortOptions={sortOptions}
        onClose={handleSortClose}
        onSelect={handleSortSelect}
      />
    </div>
  );
}

export default ShopPage;
