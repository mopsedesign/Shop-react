
  # Production-Ready React App

  This is a code bundle for Production-Ready React App. The original project is available at https://www.figma.com/design/HfKz6HUCDWeR7UrUttgRqE/Production-Ready-React-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  